#!/usr/bin/env python2
#HEAD#########################################################
#
# Katana Framework | Import Core                        
# Last Modified: 24/12/2016
#
#########################################################HEAD#

from core.Design import *     
from core.Default import *
from core.APIs import *

